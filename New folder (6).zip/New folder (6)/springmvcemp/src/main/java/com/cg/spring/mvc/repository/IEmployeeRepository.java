package com.cg.spring.mvc.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.mvc.beans.Employee;

@Repository
public interface IEmployeeRepository {
	
	List<Employee> getAllDetails();
	
	void addEmployeeDetails(Employee e);
	
	Employee getEmployeeById(int id);
	
	void deleteEmployeeById(int id);

	Employee updateEmployeeById(int id ,String name, double salary);
}
