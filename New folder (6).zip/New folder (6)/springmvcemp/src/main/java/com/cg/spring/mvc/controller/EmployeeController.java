package com.cg.spring.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.beans.Employee;
import com.cg.spring.mvc.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService service;
	
	
	@RequestMapping(value="/getemp", method=RequestMethod.GET)
	public ModelAndView getAllProducts()
	{
		ModelAndView mv = new ModelAndView("showall");//showall.jsp
		mv.addObject("employees", service.getAllDetails());
		return mv;
	}
	
	@RequestMapping(value="/addempl",method=RequestMethod.GET)
	public ModelAndView addEmpDetails()
	{
		ModelAndView mv = new ModelAndView("addemp");
		mv.addObject("command", new Employee());
		return mv;
	}
	
	@RequestMapping(value="/addemployee",method=RequestMethod.POST)
	public String addEmployee(Employee e)
	{
		service.addEmployeeDetails(e);
		return "redirect:/getemp";
		
	}
	
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public ModelAndView searchEmployeeById(@RequestParam("id") int id)
	{
		ModelAndView mv= new ModelAndView("searchemp");
		mv.addObject("employee",service.getEmployeeById(id));
		return mv;
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String deleteEmployeeById(@RequestParam("id") int id)
	{
		service.deleteEmployeeById(id);
		return "redirect:/getemp";
		
	}
	
	@RequestMapping(value="/updateempl",method=RequestMethod.GET)
	public ModelAndView updateDetails(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("salary") double salary)
	{
		ModelAndView mv= new ModelAndView("updateemp");
		mv.addObject("update", service.updateEmployeeById(id, name, salary));
		return mv;
	}
	
	
	
	
	
}
