package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.spring.mvc.beans.Employee;

@Service
public interface IEmployeeService {

	List<Employee> getAllDetails();
	
	
	void addEmployeeDetails(Employee e);
	
	Employee getEmployeeById(int id);
	
	void deleteEmployeeById(int id);
	
	Employee updateEmployeeById(int id ,String name, double salary);
	
}
