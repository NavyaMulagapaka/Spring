package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.cg.spring.mvc.beans.Employee;
import com.cg.spring.mvc.repository.IEmployeeRepository;

@Component
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeRepository repo;
	
	
	public List<Employee> getAllDetails() {
		
		
		return repo.getAllDetails();
	}


	public void addEmployeeDetails(Employee e) {
		
		repo.addEmployeeDetails(e);
	}


	public Employee getEmployeeById(int id) {
		
		return repo.getEmployeeById(id);
	}


	public void deleteEmployeeById(int id) {
		repo.deleteEmployeeById(id);
		
	}


	public Employee updateEmployeeById(int id, String name,double salary) {
		
		return repo.updateEmployeeById(id,name, salary);
		
	}
	
	

}
