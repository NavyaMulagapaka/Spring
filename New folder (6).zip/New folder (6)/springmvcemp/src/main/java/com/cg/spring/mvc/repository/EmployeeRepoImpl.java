package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Employee;

@Component
public class EmployeeRepoImpl implements IEmployeeRepository {

	List<Employee> list = new ArrayList<Employee>();
	
	
	
	public List<Employee> getAllDetails() {
		
		Employee e1= new Employee();
		
		e1.setId(list.size()+1);
		e1.setName("Pooja");
		e1.setSalary(25000);
		list.add(e1);
		Employee e2= new Employee();
		
		e2.setId(list.size()+1);
		e2.setName("vindhya");
		e2.setSalary(25000);
		
		
		list.add(e2);
		
		return list;
	}



	public void addEmployeeDetails(Employee e) {
		
		
		
		e.setId(list.size()+1);
		list.add(e);
		
		
		
	}



	public Employee getEmployeeById(int id) {
		for (Employee e:list)
		{
			if(e.getId()==id)
			{
				return e;
			}
			
		}
		return null;
		
	}



	public void deleteEmployeeById(int id) {
		
		for (Employee e:list)
		{
			if(e.getId()==id)
			{
				list.remove(e);
			}
			
		}
		
	}



	public Employee updateEmployeeById(int id,String name,double salary) {
		for(Employee e:list)
		{
			if(e.getId()==id)
			{
				e.setSalary(salary);
				e.setName(name);
				return e;
			}
		}
		return null;
		
	}

}
