package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.*;
import com.example.demo.repository.IProductRepo;

@Component
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductRepo repo;
	
	@Override
	public List<Product> getAllProducts() {
		
		return repo.getAllProducts();
	}

	@Override
	public void addProducts(int id, String name, double price) {
		repo.addProducts(id, name, price);
		
	}

	@Override
	public void updateProducts(int id, String name, double price) {
		repo.updateProducts(id, name, price);
		
	}

}
