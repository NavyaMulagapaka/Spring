package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.*;


@RestController
@ComponentScan(basePackages="com.example.demo")

public class ProductController {

	@Autowired
	IProductService service;
	
	@RequestMapping(value="/getall")
	public List<Product> getProducts()
	{
		return service.getAllProducts();
	}
	
	@RequestMapping(value="/add/{id},{name},{price}")
	public String addproducts(@PathVariable("id") int id,@PathVariable("name") String name,@PathVariable("price") double price)
	{
		service.addProducts(id, name, price);
		return "Product added sucessfully";
	}
	
	@RequestMapping(value="/update/{id},{name},{price}")
	public String updateProducts(@PathVariable("id") int id,@PathVariable("name") String name,@PathVariable("price") double price)
	{
		service.updateProducts(id, name, price);
		return "Updated sucessfully";
	}
	
}

