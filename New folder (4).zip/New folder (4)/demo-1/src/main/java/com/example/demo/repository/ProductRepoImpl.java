package com.example.demo.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.repository.IProductRepo;
import com.example.demo.*;

@Component

public class ProductRepoImpl implements IProductRepo {

 
List<Product>list = new ArrayList<>();
 
@Autowired
EntityManager entitymanager;
 
@Override
 @Transactional
public List<Product> getAllProducts() {
 

return list;

}

@Override
@Transactional
public void addProducts(int id, String name, double price) {
	Product p= new Product();
	
	p.setId(id);
	p.setName(name);
	p.setPrice(price);
	
	entitymanager.persist(p);
	
}

@Override
@Transactional
public void updateProducts(int id, String name, double price) {
	
	Product p= entitymanager.find(Product.class, id);
	
	p.setName(name);
	p.setPrice(price);
	entitymanager.persist(p);
}




}