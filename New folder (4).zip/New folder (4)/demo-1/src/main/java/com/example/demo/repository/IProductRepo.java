package com.example.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.Product;

@Repository
public interface IProductRepo {

	public List<Product> getAllProducts();
	
	
	void addProducts(int id,String name,double price);
	
	void updateProducts(int id,String name,double price);
	
	
}
