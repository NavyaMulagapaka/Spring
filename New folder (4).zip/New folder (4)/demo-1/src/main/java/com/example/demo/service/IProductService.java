package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.Product;

@Service
public interface IProductService {

	public List<Product> getAllProducts();
	void addProducts(int id, String name, double price);
	void updateProducts(int id, String name, double price);
}
