package com.cg.spring.core.beans;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Customer {

	private String fname;
	private String lname;
	private Address addr;
	Map<Integer, String> map;
	public Map<Integer, String> getMap() {
		return map;
	}
	public void setMap(Map<Integer, String> map) {
		this.map = map;
	}
	Set<String> set;
	
	List<Address> list;
	public List<Address> getList() {
		return list;
	}
	public Set<String> getSet() {
		return set;
	}
	public void setSet(Set<String> set) {
		this.set = set;
	}
	public void setList(List<Address> list) {
		this.list = list;
	}
	@Override
	public String toString() {
		return "Customer [fname=" + fname + ", lname=" + lname + ", addr=" + addr + ", map=" + map + ", set=" + set
				+ ", list=" + list + "]";
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	public Customer(String fname, String lname, Address addr) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.addr = addr;
	}
	public Customer() {
		
	}
	
}
