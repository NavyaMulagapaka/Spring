package com.cg.spring.core.beans;

public class Customer {

	private String fname;
	private String lname;
	private Address addr;
	@Override
	public String toString() {
		return "Customer [fname=" + fname + ", lname=" + lname + ", addr=" + addr + "]";
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	
	
}
