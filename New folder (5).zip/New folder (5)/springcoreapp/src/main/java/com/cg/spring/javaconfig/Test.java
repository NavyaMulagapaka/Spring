package com.cg.spring.javaconfig;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProductConfiguration.class);
		
		Product p= context.getBean(Product.class);//Constructor type injection and getters and setters type injection
		System.out.println(p);
		
		
		
		
		
	}

}
