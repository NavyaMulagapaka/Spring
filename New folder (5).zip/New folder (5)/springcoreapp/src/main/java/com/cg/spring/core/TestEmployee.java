package com.cg.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static <ConfigurableApplicationContext> void main(String[] args) {
		
		/*Employee e1 = new Employee();
		e1.setName("Vijay");
		System.out.println(e1);
		Instead of this we are using Application context container to directly
		load the Employee bean class*/
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");No close method thats why we
		//cant see destroy method getting executed
		
		ConfigurableApplicationContext context = new ConfigurableApplicationContext("spring.xml");//By using this we can execute destroy method
		Employee e1= context.getBean(Employee.class);
		/*e1.setId(123);
		e1.setName("mukesh");
		e1.setSalary(120007); These are removed because data is being set for bean by 
		constructor type injection in xml file*/
		
		System.out.println(e1);
		
		
		
		
		Manager m1= context.getBean(Manager.class);
		
		/*m1.setdNo(1);
		m1.setProjectCode(56);
		m1.setProjectName("JAVA"); we are setting the values for manager bean class in xml file so no need to set here
		for this manager bean we are setting values using setter type injection*/
		System.out.println(m1);
		context.close();
		

	}

}
