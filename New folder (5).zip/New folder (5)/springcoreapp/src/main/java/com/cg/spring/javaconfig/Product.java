package com.cg.spring.javaconfig;

public class Product {
	
	
	private String productName;
	private double productprice;
	
	
	public Product() {
		super();
	}



	public Product(String productName, double productprice) {
		super();
		this.productName = productName;
		this.productprice = productprice;
	}
	
	

	public String getProductName() {
		return productName;
	}



	public void setProductName(String productName) {
		this.productName = productName;
	}



	public double getProductprice() {
		return productprice;
	}



	public void setProductprice(double productprice) {
		this.productprice = productprice;
	}



	@Override
	public String toString() {
		return "Product [productName=" + productName + ", productprice=" + productprice + "]";
	}
	
	

}
