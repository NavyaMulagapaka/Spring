package com.cg.spring.core;

public class Manager {

	private int dNo;
	private String projectName;
	private int projectCode;
	
	
	public int getdNo() {
		return dNo;
	}
	public void setdNo(int dNo) {
		this.dNo = dNo;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public int getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(int projectCode) {
		this.projectCode = projectCode;
	}
	@Override
	public String toString() {
		return "Manager [dNo=" + dNo + ", projectName=" + projectName + ", projectCode=" + projectCode + "]";
	}
	
	
	
}
