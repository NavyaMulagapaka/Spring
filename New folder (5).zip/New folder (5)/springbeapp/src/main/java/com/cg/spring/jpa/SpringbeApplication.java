package com.cg.spring.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.spring.jpa")
public class SpringbeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbeApplication.class, args);
	}
}
