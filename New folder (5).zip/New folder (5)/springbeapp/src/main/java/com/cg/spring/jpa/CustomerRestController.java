package com.cg.spring.jpa;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerRestController {

	@Autowired
	ICustomerService service;
	@RequestMapping(value="/getall",method=RequestMethod.GET)
	public List<Customer> getAll()
	{
		return service.getAll();
	}
	
	@RequestMapping(value="/add1",method=RequestMethod.POST)
	public String add(@RequestBody Customer c)
	{
		service.addCustomers(c);
		return "Success";
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String deleteCustomer(@RequestParam("id") int id)
	{
		service.deleteCustomer(id);
		return "Success";
	}
	
	
}
