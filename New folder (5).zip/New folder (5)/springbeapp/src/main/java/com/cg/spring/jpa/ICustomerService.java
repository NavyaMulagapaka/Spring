package com.cg.spring.jpa;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface ICustomerService {

	public List<Customer> getAll();
	
	public void addCustomers(Customer c);
	
	public void deleteCustomer(int id);
}
